"""生成者：Kiro。规则评分；开放题导出盲评单，禁止冒充双评审。"""
import json,re,pathlib,subprocess,tempfile,unicodedata,os,resource,hashlib
import jsonschema
HERE=pathlib.Path(__file__).resolve().parent
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s)).strip('。.')
def code_run(code,tests):
 # 沙箱仅暴露运行库，不暴露宿主home、网络、凭据；写入限/tmp，10秒限时。
 match=re.search(r'```(?:python)?\s*\n(.*?)```',code,re.S);code=match.group(1) if match else code
 if any(x in code for x in ['socket','requests','subprocess','os.system','eval(','exec(','__import__','ctypes']):return None,'代码含需人工安全审查的功能，未执行'
 command=['bwrap','--unshare-all','--die-with-parent','--new-session','--clearenv','--setenv','PATH','/usr/bin','--ro-bind','/usr','/usr','--ro-bind','/lib','/lib','--ro-bind','/lib64','/lib64','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--chdir','/tmp','/usr/bin/python3','-I','-c',code+'\n'+tests]
 def limits():resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(8,8));resource.setrlimit(resource.RLIMIT_FSIZE,(1024**2,1024**2))
 try:
  p=subprocess.run(command,capture_output=True,text=True,timeout=10,preexec_fn=limits)
  return (1 if p.returncode==0 else 0),'bwrap通过' if p.returncode==0 else '单测失败：'+p.stderr[-500:]
 except subprocess.TimeoutExpired:return 0,'bwrap单测超时'
def score(c,r):
 if r.get('status')!='completed':return None,'运行失败或门禁中止，非能力得分'
 text=r['response'];ch=c['checks'][0];typ=ch['type']
 if c['id']=='A15':
  if norm(text)=='消极':return 1,'情绪分类精确匹配'
  if any(x in text for x in ['消极','负面','失望']):return .5,'情绪正确但未按要求只输出一个词'
  return 0,'情绪分类错误'
 if typ=='exact':return (1 if norm(text) in [norm(x) for x in ch['expected']] else 0),'归一化精确匹配'
 if typ=='contains':
  hits=sum(x in text for x in ch['all']);return (1 if hits==len(ch['all']) else .5 if hits else 0),'关键词覆盖（非语义最终确认）'
 if typ=='regex':return (1 if re.search(ch['pattern'],text) else 0),'正则匹配'
 if typ=='json_schema':
  try:jsonschema.validate(json.loads(text),ch['schema']);return 1,'严格JSON schema通过'
  except Exception:return 0,'严格JSON schema未通过'
 if typ=='code_exec':return code_run(text,ch['test_code'])
 return None,'待两名独立盲评；不能作为最终总分'
if __name__=='__main__':
 cases={c['id']:c for c in map(json.loads,(HERE/'cases_105.jsonl').read_text().splitlines())}
 raw=list(map(json.loads,(HERE/'原始结果_local.jsonl').read_text().splitlines()));rows=[];blind=[]
 for r in raw:
  s,reason=score(cases[r['id']],r);rows.append({'id':r['id'],'repetition':r['repetition'],'score':s,'reason':reason})
  if s is None and r['status']=='completed':blind.append({'blind_id':hashlib.sha256((r['id']+str(r['repetition'])).encode()).hexdigest()[:12],'case_id':r['id'],'prompt':cases[r['id']]['prompt'],'answer':r['response'],'rubric':cases[r['id']]['rubric'],'reviewer_1':None,'reviewer_2':None,'adjudicator':None})
 (HERE/'规则评分.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));(HERE/'开放题盲评单.json').write_text(json.dumps(blind,ensure_ascii=False,indent=2))
 print('规则评分',len([r for r in rows if r['score'] is not None]),'开放题待盲评',len(blind))
