"""生成者：Kiro。独立Genie测试，不修改运行服务或原bundle。"""
import json,os,pathlib,selectors,signal,subprocess,tempfile,time,base64
# 首行由runner插入PAYLOAD常量（base64），避免shell解析题目。
payload=json.loads(base64.b64decode(PAYLOAD))
def telemetry():
 vals=[float(p.read_text())/1000 for p in pathlib.Path('/sys/class/thermal').glob('thermal_zone*/temp')]
 mem=dict((a.split(':')[0],int(a.split(':')[1].split()[0])) for a in pathlib.Path('/proc/meminfo').read_text().splitlines() if ':' in a and a.split(':')[1].split() and a.split(':')[1].split()[0].isdigit())
 return {'temperature_c':max(vals),'mem_available_kib':mem['MemAvailable']}
start=time.monotonic();samples=[];result={'raw':'','error':None,'usage':None,'ttft_s':None,'ttft_scope':'Genie stdout [BEGIN]后首个文本字节，非OpenAI bridge首内容事件','requested':payload,'generator':'Kiro'}
with tempfile.TemporaryDirectory(prefix='kiro-eval-') as tmp:
 tmp=pathlib.Path(tmp);cfg=json.loads(pathlib.Path('/data/local/tmp/qnn/deepseek-7b/deepseek-7b-htp_sharing.json').read_text())
 cfg['dialog']['sampler'].update(temp=0.0,**{'top-p':1.0,'greedy':True,'seed':42})
 (tmp/'config.json').write_text(json.dumps(cfg));result['effective_sampler']=cfg['dialog']['sampler'];result['max_tokens_enforced']=False
 prompt='<｜begin▁of▁sentence｜>System: 你是严谨的中文助手。遵守题目要求，不编造实时信息。\n\nUser: '+payload['prompt']+'\n\nAssistant: '
 (tmp/'prompt.txt').write_text(prompt)
 before=telemetry();samples.append(before)
 if before['temperature_c']>=85: result['error']='thermal_precheck: >=85C，未启动推理'
 else:
  env=dict(os.environ,ADSP_LIBRARY_PATH='/data/local/tmp/qnn/dsp/lib');env['LD_LIBRARY_PATH']='/data/local/tmp/qnn/lib:'+env.get('LD_LIBRARY_PATH','')
  proc=subprocess.Popen(['/data/local/tmp/qnn/bin/genie-t2t-run','-c',str(tmp/'config.json'),'--prompt_file',str(tmp/'prompt.txt'),'--profile',str(tmp/'profile.json')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  sel=selectors.DefaultSelector();sel.register(proc.stdout,selectors.EVENT_READ);chunks=[];last=0
  while proc.poll() is None:
   now=time.monotonic()
   if now-last>=1:
    t=telemetry();t['elapsed_s']=now-start;samples.append(t);last=now
    if t['temperature_c']>=90 or t['mem_available_kib']<512000 or now-start>=120:
     result['error']='thermal_abort' if t['temperature_c']>=90 else ('memory_abort' if t['mem_available_kib']<512000 else 'timeout_120s')
     os.killpg(proc.pid,signal.SIGTERM)
     try:proc.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
     break
   for key,_ in sel.select(timeout=.2):
    data=os.read(key.fileobj.fileno(),65536)
    if data:
     chunks.append(data)
     text=b''.join(chunks).decode('utf-8',errors='replace')
     if result['ttft_s'] is None and '[BEGIN]:' in text and text.split('[BEGIN]:',1)[1].strip():result['ttft_s']=time.monotonic()-start
  rest=proc.stdout.read();chunks.append(rest);result['raw']=b''.join(chunks).decode('utf-8',errors='replace');result['returncode']=proc.returncode
  if proc.returncode and not result['error']:result['error']='genie_exit_'+str(proc.returncode)
  profile=tmp/'profile.json'
  if profile.exists():
   try:result['profile']=json.loads(profile.read_text())
   except Exception:result['profile_raw']=profile.read_text()
result['telemetry']=samples;result['wall_s']=time.monotonic()-start
print(json.dumps(result,ensure_ascii=False))
