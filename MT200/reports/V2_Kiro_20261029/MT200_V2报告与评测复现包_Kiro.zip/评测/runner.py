"""生成者：Kiro。复现：python3 runner.py --limit 1；python3 runner.py --resume。"""
import argparse,base64,json,pathlib,re,subprocess,time,hashlib,os
HERE=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--resume',action='store_true');p.add_argument('--model',default='local',choices=['local','cloud']);a=p.parse_args()
cases=[json.loads(x) for x in (HERE/'cases_105.jsonl').read_text().splitlines()]
out=HERE/('原始结果_'+a.model+'.jsonl');done=set()
if a.resume and out.exists(): done={(r['id'],r['repetition']) for r in map(json.loads,out.read_text().splitlines())}
elif out.exists(): raise SystemExit('输出已存在，请使用--resume')
worker=(HERE/'remote_worker.py').read_text();n=0
for c in cases:
 prompts=c.get('variants') or [c['prompt']]*c.get('repetitions',1)
 for rep,prompt in enumerate(prompts,1):
  if (c['id'],rep) in done:continue
  if a.limit is not None and n>=a.limit:raise SystemExit(0)
  n+=1;r={'id':c['id'],'dimension':c['dimension'],'repetition':rep,'generator':'Kiro','model':'deepseek-7b-npu' if a.model=='local' else 'deepseek-v4-flash','source':'附件索引重建题集','case_sha256':hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'timestamp':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
  if a.model=='cloud':
   if not os.environ.get('PHICOTEK_API_KEY'):r.update(error='missing_credentials',status='not_run',response=None)
   else:
    import requests
    t=time.monotonic()
    try:
     payload={'model':'deepseek-v4-flash','messages':[{'role':'system','content':'你是严谨的中文助手。遵守题目要求，不编造实时信息。'},{'role':'user','content':prompt}],'temperature':0,'top_p':1,'max_tokens':2048 if c['dimension']=='F' else 1024}
     response=requests.post('https://ai.phicotek.com/api/llmrouter/v1/chat/completions',json=payload,headers={'Authorization':'Bearer '+os.environ['PHICOTEK_API_KEY']},timeout=120);response.raise_for_status();r.update(raw=response.text,wall_s=time.monotonic()-t,status='completed',response=response.json()['choices'][0]['message']['content'],usage=response.json().get('usage'),ttft_s=None,ttft_scope='未测量')
    except Exception as exc:r.update(error=type(exc).__name__,status='failed',response=None,wall_s=time.monotonic()-t)
  else:
   payload={'prompt':prompt,'requested_max_tokens':c['max_tokens'],'case_id':c['id']};encoded=base64.b64encode(json.dumps(payload,ensure_ascii=False).encode()).decode();code='PAYLOAD='+repr(encoded)+'\n'+worker
   t=time.monotonic()
   try:
    pr=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','mt200','python3 -'],input=code,capture_output=True,text=True,timeout=145)
    if pr.returncode: r.update(error='ssh_worker_failed',stderr=pr.stderr,status='failed',response=None,wall_s=time.monotonic()-t)
    else:
     result=json.loads(pr.stdout);r.update(result);raw=result['raw'];m=re.search(r'\[BEGIN\]:(.*?)\[END\]',raw,re.S);r['response']=m.group(1).strip() if m else None;r['status']='failed' if r.get('error') or not r['response'] else 'completed';r['client_wall_s']=time.monotonic()-t
   except Exception as exc:r.update(error=type(exc).__name__+': '+str(exc),status='failed',response=None,wall_s=time.monotonic()-t)
  with out.open('a') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
  temps=[x['temperature_c'] for x in r.get('telemetry',[])];print(json.dumps({'id':r['id'],'rep':rep,'status':r['status'],'wall_s':round(r.get('wall_s',0),2),'temp_peak':max(temps) if temps else None,'error':r.get('error')},ensure_ascii=False),flush=True)
  if a.model=='local' and r.get('error') in ['thermal_abort','memory_abort','timeout_120s']:
   print('门禁已触发，暂停整轮，不向剩余题继续施压。',flush=True);raise SystemExit(3)
